# -*- coding: utf-8 -*-
###############################################################################
#
#    Serenco JSC, Open Source Management Solution
#    Copyright (C) 2006 Serenco JSC (<http://serenco.net>). All Rights Reserved
#    @author: Minh.HQ <minh.hq@serenco.net>
#
###############################################################################

from . import translate

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: