git config --global core.excludesfile ignore.txt
