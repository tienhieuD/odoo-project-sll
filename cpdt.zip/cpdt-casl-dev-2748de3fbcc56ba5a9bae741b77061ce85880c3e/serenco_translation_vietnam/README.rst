.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

==============================
Serenco Vietnamese Translation
==============================

Vietnamese Translation for Odoo 9.0x

Installation
============

No special setup

Configuration
=============

Known issues / Roadmap
======================

Usage
=====

Bug Tracker
===========

Credits
=======

Contributors
------------

* Minh HQ <minh.hq@serenco.net>

Maintainer
----------

.. image:: http://i286.photobucket.com/albums/ll109/kingpro_Lovely/icon_zpsajogpsdu.png
   :alt: Serenco JSC
   :target: http://serenco.net/

This module is maintained by the Serenco JSC.

To contribute to this module, please visit http://serenco.net.
