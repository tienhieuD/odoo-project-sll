# -*- coding: utf-8 -*-

import ir_ui_view
import res_config
