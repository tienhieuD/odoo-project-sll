*Requirements

GeoIP library

To install it using pip

$ pip install GeoIP


Screenshot
<img src="https://cloud.githubusercontent.com/assets/13301885/10918553/3b014d4a-825e-11e5-844b-b49c1d66da3d.png"/>
